using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitToMenu : MonoBehaviour
{
    public void quit()
    {
        Application.Quit();
    }
}
